package modelo;


import java.time.LocalDate;

public class Constancia {
    private Alumno alumno;

    public Constancia(Alumno alumno) {
        this.alumno = alumno;
    }

    public String generarConstancia() {
        String fechaEmision = LocalDate.now().toString();
        return  """
                  ----- CONSTANCIA DE INSCRIPCION -----
                  Fecha: """ + fechaEmision + "\n" +
                " Alumno: " + alumno.getNombre() + "\n" +
                " ID: " + alumno.getIdAlumno() + "\n" +
                " Semestre: " + alumno.getSemestre() + "\n" +
                " Materias inscritas: " + alumno.getMaterias() + "\n" +
                " Programa: " + alumno.getPrograma() + "\n" +
                " -------------------------------------\n";
    }
}

