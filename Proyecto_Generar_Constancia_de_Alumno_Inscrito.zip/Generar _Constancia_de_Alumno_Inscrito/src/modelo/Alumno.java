package modelo;

import java.util.List;

public class Alumno {
    private String idAlumno;
    private String nombre;
    private int semestre;
    private List<String> materias;
    private String programa;

    public Alumno(String idAlumno, String nombre, int semestre, List<String> materias, String programa) {
        this.idAlumno = idAlumno;
        this.nombre = nombre;
        this.semestre = semestre;
        this.materias = materias;
        this.programa = programa;
    }

    public String getIdAlumno() {
        return idAlumno;
    }

    public String getNombre() {
        return nombre;
    }

    public int getSemestre() {
        return semestre;
    }

    public List<String> getMaterias() {
        return materias;
    }

    public String getPrograma() {
        return programa;
    }
}