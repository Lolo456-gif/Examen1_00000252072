
package vista;

import controlador.ControladorConstancia;
import java.util.List;
import java.util.Scanner;
import modelo.Alumno;
import modelo.Constancia;

public class VistaConstancia {
    private ControladorConstancia controlador;
    private Scanner sc;

    public VistaConstancia(ControladorConstancia controlador) {
        this.controlador = controlador;
        this.sc = new Scanner(System.in);
    }

    public void iniciar() {
        System.out.println("=== GENERAR CONSTANCIA DE ALUMNO INSCRITO ===");
        System.out.print("Ingrese ID del alumno: ");
        String id = sc.nextLine();

        List<Alumno> resultados = controlador.buscarCoincidencias(id);

        if (resultados.isEmpty()) {
            System.out.println("No se encontraron alumnos con ese ID.");
            return;
        }

        System.out.println("Alumnos encontrados:");
        for (int i = 0; i < resultados.size(); i++) {
            System.out.println((i + 1) + ". " + resultados.get(i).getNombre() + " (ID: " + resultados.get(i).getIdAlumno() + ")");
        }

        System.out.print("Seleccione el numero del alumno para generar constancia: ");
        int seleccion = sc.nextInt();
        sc.nextLine();

        if (seleccion < 1 || seleccion > resultados.size()) {
            System.out.println("Seleccion invalida.");
            return;
        }

        Alumno alumnoSeleccionado = resultados.get(seleccion - 1);
        String constancia = controlador.generarConstancia(alumnoSeleccionado);

        System.out.println("\n" + constancia);
    }
}