package main;

import controlador.ControladorConstancia;
import vista.VistaConstancia;

public class Main {
    public static void main(String[] args) {
        ControladorConstancia controlador = new ControladorConstancia();
        VistaConstancia vista = new VistaConstancia(controlador);
        vista.iniciar();
    }
}
