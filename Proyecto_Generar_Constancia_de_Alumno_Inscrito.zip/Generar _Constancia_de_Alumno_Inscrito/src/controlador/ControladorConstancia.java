package controlador;

import modelo.Alumno;
import modelo.Constancia;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ControladorConstancia {
    private List<Alumno> listaAlumnos;

    public ControladorConstancia() {
        listaAlumnos = new ArrayList<>();
        listaAlumnos.add(new Alumno("1", "Ana Perez", 1, Arrays.asList("Matematicas", "Programacion"), "ISW"));
        listaAlumnos.add(new Alumno("2", "Luis Gomez", 2, Arrays.asList("Bases de Datos", "Redes"), "ISW"));
        listaAlumnos.add(new Alumno("3", "Maria Lopez", 1, Arrays.asList("Algoritmos", "Fisica"), "ISW"));
        listaAlumnos.add(new Alumno("4", "Juan Martinez", 3, Arrays.asList("Ingenieria de Software", "Matematicas"), "ISW"));
        listaAlumnos.add(new Alumno("5", "Carla Torres", 2, Arrays.asList("Programacion", "Quimica"), "ISW"));
        listaAlumnos.add(new Alumno("6", "Pedro Sanchez", 1, Arrays.asList("Bases de Datos", "Fisica"), "ISW"));
        listaAlumnos.add(new Alumno("7", "Sofia Ramirez", 3, Arrays.asList("Redes", "Matematicas"), "ISW"));
        listaAlumnos.add(new Alumno("8", "Diego Fernandez", 2, Arrays.asList("Programacion", "Algoritmos"), "ISW"));
        listaAlumnos.add(new Alumno("9", "Laura Hernandez", 1, Arrays.asList("Quimica", "Fisica"), "ISW"));
        listaAlumnos.add(new Alumno("10", "Carlos Jimenez", 3, Arrays.asList("Ingenieria de Software", "Redes"), "ISW"));
    }

    public List<Alumno> buscarCoincidencias(String id) {
        List<Alumno> resultados = new ArrayList<>();
        for (Alumno a : listaAlumnos) {
            if (a.getIdAlumno().contains(id)) {
                resultados.add(a);
            }
        }
        return resultados;
    }

    public String generarConstancia(Alumno alumno) {
        Constancia c = new Constancia(alumno);
        return c.generarConstancia();
    }
}